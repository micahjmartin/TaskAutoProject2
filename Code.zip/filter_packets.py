def filter() :
	print 'called filter function in filter_packets.py'
	
