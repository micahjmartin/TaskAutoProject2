def compute() :
	print 'called compute function in compute_metrics.py'

