def parse() :
	print 'called parse function in packet_parser.py'

	